### Elementor Icons ###

Repo for [Elementor](https://github.com/pojome/elementor) Icons

See it in action: [Icons Demo](https://elementor.github.io/elementor-icons/)

== Copyright ==

Some icons in this library are based on Font Awesome 4.7.0 licensed under SIL OFL 1.1
